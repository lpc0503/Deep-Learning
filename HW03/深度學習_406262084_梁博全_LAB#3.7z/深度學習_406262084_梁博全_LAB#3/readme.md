---
title: readme
---

 <font size="50" color="red">新年快樂</font>

:::info
執行 main.py 後會產生 output_for_assistance.txt
此輸出檔是給助教測試產生的
我的輸出檔為 test.txt
:::


# 根目錄下的檔案

* `source code`資料夾:
    * 存放原始碼及`output`和資料

* `readme.md`
    * 此份檔案

# source code

* `train_img.txt`
    * training 資料
* `train_label.txt`
    * training label 資料 
* `test_img.txt`
    * testing 資料
* `main.py`
    * 程式